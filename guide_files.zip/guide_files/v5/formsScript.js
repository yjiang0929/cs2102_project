function show() {
	// Get Values
	var matric  = document.getElementById('matric' ).value;
	var name    = document.getElementById('name'   ).value;
	var faculty = document.getElementById('faculty').value;
	
	// Alert
	alert("--- Your Input ---\nMatric: " + matric + "\nName: " + name + "\nFaculty: " + faculty);
}